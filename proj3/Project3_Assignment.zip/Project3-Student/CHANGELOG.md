Jul 7, 2016 - by Ruian
1. Fix compatibility in c++ compilation. Thanks to [@Brad](https://piazza.com/class/io64qcv6qtp1hx?cid=723)
2. Fix the compatibility for print statement between python2 and python3.
3. Add hint for Task3, fix error in Task3-Q1
Jul 10, 2016 - by Ruian
1. Fix the confusion about probabilities in Task3-Q2. Thanks to [@Alex](https://piazza.com/class/io64qcv6qtp1hx?cid=747)